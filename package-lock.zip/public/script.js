let fuelEconomyChart; // Declare a variable to hold the chart instance
let compareChart; // Declare a variable to hold the compare chart instance

// Fetch vehicle models and years when the page loads
window.onload = function() {
    fetch('/api/vehicles')
        .then(response => response.json())
        .then(data => {
            const modelSelect = document.getElementById('model');
            if (modelSelect) {
                data.vehicles.forEach(vehicle => {
                    const option = document.createElement('option');
                    option.value = vehicle;
                    option.textContent = vehicle;
                    modelSelect.appendChild(option);
                });

                // Add event listener for model search
                document.getElementById('modelSearch').addEventListener('input', function() {
                    filterDropdown('modelSearch', 'model');
                });
            }
        })
        .catch(error => {
            console.error('Error fetching vehicle models:', error);
        });

    fetch('/api/years')
        .then(response => response.json())
        .then(data => {
            const yearSelect = document.getElementById('year');
            if (yearSelect) {
                data.years.forEach(year => {
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    yearSelect.appendChild(option);
                });

                // Add event listener for year search
                document.getElementById('yearSearch').addEventListener('input', function() {
                    filterDropdown('yearSearch', 'year');
                });
            }
        })
        .catch(error => {
            console.error('Error fetching years:', error);
        });
};

// Handle form submission to fetch and display fuel economy data
document.getElementById('fuelForm')?.addEventListener('submit', function(event) {
    event.preventDefault();
    
    const model = document.getElementById('model').value;
    const year = document.getElementById('year').value;

    fetch(`/api/fuel-economy?model=${model}&year=${year}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Fetched data:', data);

                // Display the results
                document.getElementById('cityMPG').textContent = data.cityMPG;
                document.getElementById('highwayMPG').textContent = data.highwayMPG;
                document.getElementById('combinedMPG').textContent = data.combinedMPG;
                document.getElementById('results').style.display = 'block';

                // Destroy the previous chart instance if it exists
                if (fuelEconomyChart) {
                    fuelEconomyChart.destroy();
                }

                // Display bar graph
                const ctx = document.getElementById('fuelEconomyChart').getContext('2d');
                fuelEconomyChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['City MPG', 'Highway MPG', 'Combined MPG'],
                        datasets: [{
                            label: `${model} ${year} Fuel Economy`,
                            data: [data.cityMPG, data.highwayMPG, data.combinedMPG],
                            backgroundColor: ['#000000', '#000000', '#000000'], // Black color
                            borderColor: ['#000000', '#000000', '#000000'], // Black color
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            } else {
                alert('Data not available for the selected vehicle and year.');
            }
        })
        .catch(error => {
            console.error('Error fetching fuel economy data:', error);
        });
});

// Function to filter dropdown options based on search input
function filterDropdown(searchId, selectId) {
    const searchInput = document.getElementById(searchId).value.toLowerCase();
    const select = document.getElementById(selectId);
    const options = select.getElementsByTagName('option');

    for (let i = 0; i < options.length; i++) {
        const optionText = options[i].textContent.toLowerCase();
        if (optionText.includes(searchInput)) {
            options[i].style.display = '';
        } else {
            options[i].style.display = 'none';
        }
    }
}

// Handle dashboard menu
document.getElementById('dashboardMenuButton')?.addEventListener('click', function() {
    const dashboardMenu = document.getElementById('dashboardMenu');
    dashboardMenu.style.display = dashboardMenu.style.display === 'block' ? 'none' : 'block';
});

// Handle compare cars button
document.getElementById('compareCarsButton')?.addEventListener('click', function() {
    window.location.href = 'compare.html';
});

// Handle number of cars form submission in compare.html
document.getElementById('numCarsSubmit')?.addEventListener('click', function(event) {
    event.preventDefault();
    const numCars = document.getElementById('numCars').value;
    if (numCars < 1 || numCars > 3) {
        alert('Please enter a number between 1 and 3.');
        return;
    }

    const carSelectionForm = document.getElementById('carSelectionForm');
    carSelectionForm.innerHTML = ''; // Clear previous dropdowns

    for (let i = 0; i < numCars; i++) {
        const carDiv = document.createElement('div');
        carDiv.classList.add('car-selection');

        const modelLabel = document.createElement('label');
        modelLabel.textContent = `Select Vehicle Model for Car ${i + 1}:`;
        carDiv.appendChild(modelLabel);

        const modelSelect = document.createElement('select');
        modelSelect.classList.add('model-select');
        modelSelect.name = `model${i + 1}`;
        carDiv.appendChild(modelSelect);

        const yearLabel = document.createElement('label');
        yearLabel.textContent = `Select Year for Car ${i + 1}:`;
        carDiv.appendChild(yearLabel);

        const yearSelect = document.createElement('select');
        yearSelect.classList.add('year-select');
        yearSelect.name = `year${i + 1}`;
        carDiv.appendChild(yearSelect);

        carSelectionForm.appendChild(carDiv);
    }

    // Populate the dropdowns with vehicle models and years
    fetch('/api/vehicles')
        .then(response => response.json())
        .then(data => {
            const modelSelects = document.querySelectorAll('.model-select');
            modelSelects.forEach(select => {
                data.vehicles.forEach(vehicle => {
                    const option = document.createElement('option');
                    option.value = vehicle;
                    option.textContent = vehicle;
                    select.appendChild(option);
                });
            });
        })
        .catch(error => {
            console.error('Error fetching vehicle models:', error);
        });

    fetch('/api/years')
        .then(response => response.json())
        .then(data => {
            const yearSelects = document.querySelectorAll('.year-select');
            yearSelects.forEach(select => {
                data.years.forEach(year => {
                    const option = document.createElement('option');
                    option.value = year;
                    option.textContent = year;
                    select.appendChild(option);
                });
            });
        })
        .catch(error => {
            console.error('Error fetching years:', error);
        });

    carSelectionForm.style.display = 'block';
});

// Handle compare cars form submission in compare.html
document.getElementById('compareSubmit')?.addEventListener('click', function(event) {
    event.preventDefault();
    const carModels = [];
    const modelSelects = document.querySelectorAll('.model-select');
    const yearSelects = document.querySelectorAll('.year-select');

    for (let i = 0; i < modelSelects.length; i++) {
        const model = modelSelects[i].value;
        const year = yearSelects[i].value;
        carModels.push({ model, year });
    }

    Promise.all(carModels.map(car => 
        fetch(`/api/fuel-economy?model=${car.model}&year=${car.year}`)
            .then(response => response.json())
    )).then(results => {
        const labels = ['City MPG', 'Highway MPG', 'Combined MPG'];
        const datasets = results.map((result, index) => {
            if (result.success) {
                return {
                    label: `${carModels[index].model} ${carModels[index].year}`,
                    data: [result.cityMPG, result.highwayMPG, result.combinedMPG],
                    backgroundColor: `rgba(${index * 100}, 0, 0, 0.5)`,
                    borderColor: `rgba(${index * 100}, 0, 0, 1)`,
                    borderWidth: 1
                };
            } else {
                alert(`Data not available for ${carModels[index].model} ${carModels[index].year}`);
                return null;
            }
        }).filter(dataset => dataset !== null);

        // Destroy the previous compare chart instance if it exists
        if (compareChart) {
            compareChart.destroy();
        }

        // Display compare chart
        const ctx = document.getElementById('compareChart').getContext('2d');
        compareChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels,
                datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        document.getElementById('compareResults').style.display = 'block';
    }).catch(error => {
        console.error('Error comparing cars:', error);
    });
});

// Vehicle data with MPG information
const vehicleData = {
    prius: { city: 58, highway: 53, combined: 56 },
    corolla: { city: 31, highway: 40, combined: 34 },
    camry: { city: 28, highway: 39, combined: 32 },
    rav4: { city: 27, highway: 35, combined: 30 },
    highlander: { city: 21, highway: 29, combined: 24 }
};

// Driving condition modifiers
const conditionModifiers = {
    city: { city: 1.0, highway: 0.8, combined: 0.9 },
    highway: { city: 0.85, highway: 1.1, combined: 1.0 },
    mixed: { city: 0.9, highway: 0.95, combined: 0.95 }
};

// Driving style modifiers
const styleModifiers = {
    eco: { multiplier: 1.15, feedback: "Great job! Your eco-friendly driving style is maximizing fuel efficiency." },
    normal: { multiplier: 1.0, feedback: "You're driving with a balanced approach to fuel economy." },
    aggressive: { multiplier: 0.8, feedback: "Consider adopting a smoother driving style to improve fuel economy." }
};

// Quiz answers
const quizAnswers = {
    quiz1: "option1", // Toyota Prius
    quiz2: "habit2"   // Maintaining steady speed
};

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Eco Challenge Form
    const ecoChallengeForm = document.getElementById('ecoChallengeForm');
    const simCityMPG = document.getElementById('simCityMPG');
    const simHighwayMPG = document.getElementById('simHighwayMPG');
    const simCombinedMPG = document.getElementById('simCombinedMPG');
    const ecoFeedback = document.getElementById('ecoFeedback');
    
    // Quiz Form
    const quizForm = document.getElementById('quizForm');
    const quizResult = document.getElementById('quizResult');
    
    // MPG Chart
    const mpgChartCtx = document.getElementById('mpgChart').getContext('2d');
    
    // Initialize MPG Chart
    const mpgChart = new Chart(mpgChartCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Monthly MPG',
                data: [30.2, 31.5, 32.8, 33.1, 32.5, 34.2],
                backgroundColor: 'rgba(229, 0, 0, 0.1)',
                borderColor: 'rgba(229, 0, 0, 1)',
                borderWidth: 2,
                tension: 0.4,
                pointBackgroundColor: 'white',
                pointBorderColor: 'rgba(229, 0, 0, 1)',
                pointBorderWidth: 2,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: false,
                    min: 25,
                    title: {
                        display: true,
                        text: 'Miles Per Gallon (MPG)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Month'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.7)',
                    padding: 10,
                    titleFont: {
                        size: 14
                    },
                    bodyFont: {
                        size: 14
                    },
                    displayColors: false
                }
            }
        }
    });
    
    // Eco Challenge Form Submission
    ecoChallengeForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const vehicle = document.getElementById('vehicle').value;
        const condition = document.getElementById('condition').value;
        const drivingStyle = document.getElementById('drivingStyle').value;
        
        // Calculate simulated MPG values
        const baseVehicleMPG = vehicleData[vehicle];
        const conditionMod = conditionModifiers[condition];
        const styleMod = styleModifiers[drivingStyle];
        
        // Apply modifiers to calculate simulated MPG
        const cityMPG = Math.round(baseVehicleMPG.city * conditionMod.city * styleMod.multiplier);
        const highwayMPG = Math.round(baseVehicleMPG.highway * conditionMod.highway * styleMod.multiplier);
        const combinedMPG = Math.round(baseVehicleMPG.combined * conditionMod.combined * styleMod.multiplier);
        
        // Update the display with calculated values
        simCityMPG.textContent = cityMPG;
        simHighwayMPG.textContent = highwayMPG;
        simCombinedMPG.textContent = combinedMPG;
        
        // Show feedback based on driving style
        ecoFeedback.textContent = styleMod.feedback;
        
        // Animate the results for better UX
        animateCounters();
        
        // Scroll to results
        document.getElementById('ecoResults').scrollIntoView({ behavior: 'smooth' });
    });
    
    // Quiz Form Submission
    quizForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get selected answers
        const quiz1Answer = document.querySelector('input[name="quiz1"]:checked')?.value;
        const quiz2Answer = document.querySelector('input[name="quiz2"]:checked')?.value;
        
        // Check if all questions are answered
        if (!quiz1Answer || !quiz2Answer) {
            quizResult.textContent = "Please answer all questions.";
            quizResult.className = "quiz-result incorrect";
            return;
        }
        
        // Check answers
        let correctAnswers = 0;
        if (quiz1Answer === quizAnswers.quiz1) correctAnswers++;
        if (quiz2Answer === quizAnswers.quiz2) correctAnswers++;
        
        // Display result
        if (correctAnswers === 2) {
            quizResult.textContent = "Congratulations! You got all answers correct.";
            quizResult.className = "quiz-result correct";
        } else if (correctAnswers === 1) {
            quizResult.textContent = "You got 1 answer correct. Keep learning!";
            quizResult.className = "quiz-result incorrect";
        } else {
            quizResult.textContent = "Try again! Review our eco-driving tips to learn more.";
            quizResult.className = "quiz-result incorrect";
        }
        
        // Scroll to result
        quizResult.scrollIntoView({ behavior: 'smooth' });
    });
    
    // Function to animate counter values
    function animateCounters() {
        const elements = [simCityMPG, simHighwayMPG, simCombinedMPG];
        
        elements.forEach(element => {
            const targetValue = parseInt(element.textContent);
            let startValue = 0;
            const duration = 1500;
            const startTime = performance.now();
            
            function updateCounter(currentTime) {
                const elapsedTime = currentTime - startTime;
                const progress = Math.min(elapsedTime / duration, 1);
                
                // Easing function for smoother animation
                const easedProgress = 1 - Math.pow(1 - progress, 3);
                
                const currentValue = Math.floor(easedProgress * targetValue);
                element.textContent = currentValue;
                
                if (progress < 1) {
                    requestAnimationFrame(updateCounter);
                } else {
                    element.textContent = targetValue;
                }
            }
            
            requestAnimationFrame(updateCounter);
        });
    }
    
    // Initialize with default values
    document.getElementById('vehicle').value = 'prius';
    document.getElementById('condition').value = 'city';
    document.getElementById('drivingStyle').value = 'normal';
});