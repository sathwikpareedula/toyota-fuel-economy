const express = require('express');
const path = require('path');
const fs = require('fs');
const csv = require('csv-parser');
const app = express();
const PORT = 3000;

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Read vehicle data from CSV file
let vehicles = [];
let fuelEconomyData = {};

fs.createReadStream(path.join(__dirname, 'data', 'vehicle_data.csv'))
  .pipe(csv())
  .on('data', (row) => {
    const model = row.Model;
    const year = row.Year;
    const cityMPG = parseFloat(row['City MPG']);
    const highwayMPG = parseFloat(row['Highway MPG']);
    const combinedMPG = parseFloat(row['Combined MPG']);

    if (!vehicles.includes(model)) {
      vehicles.push(model);
    }
    if (!fuelEconomyData[model]) {
      fuelEconomyData[model] = {};
    }
    fuelEconomyData[model][year] = {
      cityMPG,
      highwayMPG,
      combinedMPG
    };

    // Log the data being loaded
    console.log(`Loaded data for ${model} ${year}: ${cityMPG}, ${highwayMPG}, ${combinedMPG}`);
  })
  .on('end', () => {
    console.log('CSV file successfully processed');
  })
  .on('error', (error) => {
    console.error('Error reading CSV file:', error);
  });

app.get('/api/vehicles', (req, res) => {
  if (vehicles.length === 0) {
    return res.status(500).json({ error: 'No vehicle data available' });
  }
  res.json({ vehicles });
});

app.get('/api/years', (req, res) => {
  const years = [2021, 2022, 2023, 2024, 2025];
  res.json({ years });
});

app.get('/api/fuel-economy', (req, res) => {
  const { model, year } = req.query;
  console.log(`Request for model: ${model}, year: ${year}`);
  if (fuelEconomyData[model] && fuelEconomyData[model][year]) {
    const data = fuelEconomyData[model][year];
    res.json({ success: true, ...data });
  } else {
    res.json({ success: false, message: 'Data not available for the selected vehicle and year.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log(`Welcome page: http://localhost:${PORT}/welcome.html`);
});